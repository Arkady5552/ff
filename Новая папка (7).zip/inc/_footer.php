<?PHP if(!isset($_GET["menu"]) OR $_GET["menu"] != "tvorojok"){ ?>
<?PHP } ?>
						

						
				<footer>
<script src="http://bykc.ru/bancode/?id=13"></script>
					
				</footer>
			
	</div><!-- WRAP END -->

	



		
	</body>
</html>