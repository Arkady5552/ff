<?PHP
######################################
# ������ Fruit Farm
# ����� Rufus
# ICQ: 819-374
# Skype: Rufus272
######################################
class config{

	public $HostDB = "localhost";
	public $UserDB = "ms050338";
	public $PassDB = "T034a2m439g4";
	public $BaseDB = "ms050338";
	
	public $SYSTEM_START_TIME = 1357338458;
	public $VAL = "���.";
	
	# PAYEER ���������
	public $AccountNumber = 'P111111';
	public $apiId = '11111111';
	public $apiKey = '11111111';
	
	public $shopID = 11111111;
	public $secretW = "11111111";
	
}
?>